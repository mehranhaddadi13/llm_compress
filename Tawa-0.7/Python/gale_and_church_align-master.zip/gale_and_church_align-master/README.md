# Gale and Church Align
This is a Python implementation of [A Program for Aligning Sentences in Bilingual Corpora](http://www.aclweb.org/anthology/J93-1004)。

see [Gale和Church的句对齐算法解析](https://zhuanlan.zhihu.com/p/59071889) for an explanation. 
